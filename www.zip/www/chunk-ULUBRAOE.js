import{b as a,c as b}from"./chunk-M2X7KQLB.js";import"./chunk-JHI3MBHO.js";export{a as GESTURE_CONTROLLER,b as createGesture};
